import { DataTypes } from 'sequelize';
import { sequelize } from '../connection.js';

export const Empresa = sequelize.define('Empresa', {
  IDEmpresa: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  nomeEmpresa: {
    type: DataTypes.STRING,
    allowNull: false
  },
  emailEmpresa: {
    type: DataTypes.STRING,
    allowNull: false
  },
  senhaEmpresa: {
    type: DataTypes.STRING,
    allowNull: false
  }
},{
  tableName: 'tbEmpresa',
  timestamps: false
});