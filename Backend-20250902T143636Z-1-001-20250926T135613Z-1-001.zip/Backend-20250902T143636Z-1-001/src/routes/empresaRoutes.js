// src/routes/empresaRoutes.js
import { Router } from 'express';
import { cadastrarEmpresa, listarEmpresas, buscarEmpresa } from '../controllers/empresa.js';

const router = Router();

router.post('/empresa', cadastrarEmpresa);      // POST /api/empresa
router.get('/empresa', listarEmpresas);         // GET  /api/empresa
router.get('/empresa/:id', buscarEmpresa);      // GET  /api/empresa/123


export default router;
