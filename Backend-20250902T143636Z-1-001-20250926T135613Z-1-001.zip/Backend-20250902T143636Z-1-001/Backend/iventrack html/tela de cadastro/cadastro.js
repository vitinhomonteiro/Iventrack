$(document).ready(function () {
  $("#cadastro-form").on("submit", function (e) {
    e.preventDefault();

    const nome = $("#nomeEmpresa").val().trim();
    const email = $("#emailEmpresa").val().trim();
    const senha = $("#senhaEmpresa").val().trim();

    // Validação: campos obrigatórios
    if (!nome || !email || !senha) {
      $("#mensagem").text("Preencha todos os campos.").css("color", "red");
      return;
    }

    // Validação: email válido
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      $("#mensagem").text("Digite um email válido.").css("color", "red");
      return;
    }

    // Validação: senha mínima 6 caracteres
    if (senha.length < 6) {
      $("#mensagem").text("A senha deve ter no mínimo 6 caracteres.").css("color", "red");
      return;
    }

    // Se tudo ok → envia para o backend
    $.ajax({
      url: "http://localhost:3000/api/empresa",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify({ nomeEmpresa: nome, emailEmpresa: email, senhaEmpresa: senha }),
      success: function (res) {
        $("#mensagem").text(res.message).css("color", "green");
        setTimeout(() => {
          window.location.href = "../tela de login/tela login.html";
        }, 1500);
      },
      error: function (xhr) {
        $("#mensagem").text(xhr.responseJSON?.message || "Erro ao cadastrar").css("color", "red");
      }
    });
  });
});
